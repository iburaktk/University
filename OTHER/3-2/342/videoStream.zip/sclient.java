import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import javafx.application.Application;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.*;

public class sclient extends Application {

    public static void main(String[] args) throws UnknownHostException, IOException {
        Application.launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        Parameters parameters = getParameters(); // Getting console arguments
        List<String> args = parameters.getRaw(); // as a list

        TextArea video = new TextArea();    // Our video screen
        video.setEditable(false);
        video.setFont(Font.font("Monospaced"));

        StackPane root = new StackPane();
    
        root.getChildren().addAll(video);
        Scene mainScene = new Scene(root);
        primaryStage.setHeight(275);        // These values for my PC.
        primaryStage.setWidth(550);         // If you are not see well, you can change this values.
        primaryStage.centerOnScreen();
        primaryStage.setTitle("Ascii Video");
        primaryStage.setScene(mainScene);
        primaryStage.show();

        
        String address = "127.0.0.1";       // Not static value, will be setted. :D
        int port = 5000, channelID = 0;
        Socket socket = null;
        DataInputStream in = null;
        DataOutputStream out = null;

        for (int i = 0; i < args.size(); i += 2) {
            String type = args.get(i);      // Argument setting
            if (type.equals("-a"))  // address
                address = args.get(i+1);
            if (type.equals("-p"))  // port
                port = Integer.valueOf(args.get(i+1));
            if (type.equals("-ch")) // channel
                channelID = Integer.valueOf(args.get(i+1));
        }
        
        try {
            socket = new Socket(address, port);
            in = new DataInputStream(socket.getInputStream());
            out = new DataOutputStream(socket.getOutputStream());
        } catch (Exception e) {
            System.out.println("Connection refused. Maybe you didn't start the server?");
            System.exit(0);
        }
        out.write(channelID); // This client wants to connect channel [channelID]
        Listen listenThread = new Listen(in, out, video);   // Thread for getting data from server
        listenThread.start();
    }
}

class Listen extends Thread {
    DataInputStream in;
    DataOutputStream out;
    TextArea video;

    public Listen(DataInputStream in, DataOutputStream out, TextArea video){
        this.in = in;
        this.out = out;
        this.video = video;
    }

    @Override
    public void run() {
        
        ArrayList<String> frame = new ArrayList<String>();
        String message = "";
        try {
            message = socketRead(in,out);   // Read first line
        } catch (IOException e) {
            e.printStackTrace();
        }
        while (!message.equals("Over")) {   // Disconnect
            if (message.startsWith("Frame")) {  // Frame readed
                StringBuilder builder = new StringBuilder();
                for (String line : frame)
                    builder.append(line + "\n");    // add new line character to all lines
                video.setText(builder.toString());  // show frame at screen
                try {
                    if (!frame.isEmpty())   // Empty frame at beginning of file, should pass
                        Thread.sleep(50);   // Otherwise, wait 50 ms to get 20 FPS.
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                frame.clear();  // Reset frame
            } else if(!message.startsWith("Empty"))
                frame.add(message); // Add line to frame
            try {
                message = socketRead(in,out);   // Read next line from server
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static String socketRead(DataInputStream in,DataOutputStream out) throws IOException {
        String message = new String(in.readNBytes(70));
        int i = 1;
        out.write(i);   // Send successful response
        return message;
    }
}