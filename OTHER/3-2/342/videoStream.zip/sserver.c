//sserver –p port –s streams –ch1 videofile [–ch2 videofile] [–ch3 videofile]

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <pthread.h>
#include <sys/types.h>
#include <semaphore.h>
#include <unistd.h>
#include <fcntl.h>

#ifndef SO_REUSEPORT
#define SO_REUSEPORT 15
#endif

#define bufferSize 10
#define charNumEachLine 70 // these may change respect to input file

typedef struct
{
    char *filename;
    char ***bufferPointer;
    int *listenerAmount;
    int channel;
} feedBufferArgument;

typedef struct
{
    int mySocket;
    char ***buffer;
    int consumerAt;
    int channel;
} streamArgument;

// function prototypes
void createSocketAndStream(char ***buffers, int port, int *listeningConsumerNum, int consumerAt);
void *feedBuffer(void *args);
void *stream(void *argument);

int main(int argc, char **argv)
{
    int port, streams;
    int consumerAt = 0; // current position consumers for synchronization
    if (argc < 5)
    {
        printf("Not enough parameters. Try again\n");
        exit(0);
    }
    for (int i = 1; i < 5; i += 2)
    {
        if (strcmp(argv[i], "-p") == 0)
            port = atoi(argv[i + 1]);
        if (strcmp(argv[i], "-s") == 0)
            streams = atoi(argv[i + 1]);
    }
    if (argc < 5 + 2 * streams)
    {
        printf("Not enough parameters. Try again\n");
        exit(0);
    }
    char *fileNames[streams];
    for (int i = 0; i < streams; i++)
        fileNames[i] = argv[6 + 2 * i];

    pthread_t *feederThreadIDs = malloc(streams * sizeof(pthread_t));
    char ***buffers = malloc(streams * sizeof(char **));
    int *listeningConsumerNums = malloc(streams * sizeof(int));
    for (int i = 0; i < streams; i++)
    {
        *(buffers + i) = malloc(bufferSize * sizeof(char *));
        for (int j = 0; j < bufferSize; j++)
        {
            *(*(buffers + i) + j) = malloc(charNumEachLine * sizeof(char));
        }
        *(listeningConsumerNums + i) = 0;

        feedBufferArgument *args = malloc(sizeof(feedBufferArgument));
        args->listenerAmount = &(*(listeningConsumerNums + i));
        args->filename = fileNames[i];
        args->bufferPointer = &(*(buffers + i));
        args->channel = i;

        pthread_create(&(*(feederThreadIDs + i)), NULL, feedBuffer, args);
        // We created our feeder threads. These threads will feed the buffer infinitely.
        // These threads use semophore's to syncronization with consumers.
    }

    createSocketAndStream(buffers, port, listeningConsumerNums, consumerAt);
}

void *feedBuffer(void *args)
{
    int producerAt = 0;
    // taking arguments back
    feedBufferArgument arguments = *(feedBufferArgument *)args;
    char *filename = arguments.filename;
    char ***buffer = arguments.bufferPointer;
    int channel = arguments.channel;
    int *listenerAmount = arguments.listenerAmount;

    // Opening semophores
    char name[20];
    sem_t *writeMutex;
    sem_t *readMutex;
    sprintf(name, "writeMutex%d", channel);
    writeMutex = sem_open(name, O_CREAT | O_RDWR, 0600, 0);
    while (*listenerAmount == 0)
        continue;
    // Waiting for a client

    sprintf(name, "readMutex%d", channel);
    readMutex = sem_open(name, O_CREAT | O_RDWR, 0600, 0);
    sem_init(readMutex, 1, 0);

    // Opening video file to read
    FILE *video = fopen(filename, "r");
    char *line = malloc(charNumEachLine * sizeof(char));
    while (1)
    {
        for (int i = 0; i < *listenerAmount; i++)
            sem_wait(writeMutex);
        // Semophore waiting (locking)
        if (!fgets(line, charNumEachLine, video))
        {
            rewind(video);
            // File rewinding to continuously streaming
            fgets(line, charNumEachLine, video);
        }
        if (strcmp(line, "1\n") == 0 || strcmp(line, "6\n") == 0)
            strncpy(line, "Frame", charNumEachLine);
        if (strcmp(line, "\n") == 0)
            strncpy(line,"Empty",charNumEachLine);
        strtok(line, "\n");
        // Writing data to buffer
        memcpy(*(*(buffer) + producerAt), line, charNumEachLine);
        for (int i = 0; i < *listenerAmount; i++)
            sem_post(readMutex);
        // Posting semophores (Releasing)
        producerAt = (producerAt + 1) % bufferSize;
    }
}

void createSocketAndStream(char ***buffers, int port, int *listeningConsumerNums, int consumerAt)
{
    // This function creates socket connection, accepts connection requests 
    // and creates threads for these connections
    int socketFileDescriptor;
    int socketOption = 1;
    int mySocket;
    pthread_t *threadIDs = malloc(sizeof(pthread_t));
    int totalThreads = 0;
    struct sockaddr_in address;
    socklen_t sizeOfAddress = sizeof(address);
    if (0 == (socketFileDescriptor = socket(AF_INET, SOCK_STREAM, 0)))
    {
        printf("Opening socket is failed.\n");
        return;
    }
    if (setsockopt(socketFileDescriptor, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &(int){1}, sizeof(int)))
    {
        printf("Setting socket options is failed.\n");
        return;
    }
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(port);
    if (0 > bind(socketFileDescriptor, (struct sockaddr *)&address, sizeof(address)))
    {
        printf("Binding socket is failed.\n");
        return;
    }
    if (0 > listen(socketFileDescriptor, 1))
    {
        printf("Listening is failed.\n");
        return;
    }
    while (mySocket = accept(socketFileDescriptor, (struct sockaddr *)&address, &sizeOfAddress))
    {
        // Accepts connection requests
        threadIDs = realloc(threadIDs, (totalThreads + 1) * sizeof(pthread_t));
        int channel;
        recv(mySocket, &channel, 4, 0);
        // Gets target channel. 
        channel--;
        *(listeningConsumerNums + channel) += 1;
        // Opens appropriate semophores
        char name[20];
        sem_t *writeMutex;
        sprintf(name, "writeMutex%d", channel);
        writeMutex = sem_open(name, O_CREAT | O_RDWR, 0600, 0);
        // There are more listeners now, thus feeder thread should wait more to synchronize.
        for (int i = 0; i < bufferSize; i++)
            sem_post(writeMutex);
        // We increase this semophore for that. Also, feeder thread 
        // will wait listeningConsumerNums times

        streamArgument *argument = malloc(sizeof(streamArgument));
        argument->buffer = &(*(buffers + channel));
        argument->mySocket = mySocket;
        argument->channel = channel;
        argument->consumerAt = consumerAt;
        pthread_create(&(*(threadIDs + totalThreads++)), NULL, stream, argument);
    }
    printf("Exit\n");
    return;
}

void *stream(void *argument)
{
    // This thread reads data from buffer and sends the data to client.

    // Getting argument
    streamArgument takenArgument = *(streamArgument *)argument;
    int socketNum = takenArgument.mySocket;
    char ***buffer = takenArgument.buffer;
    int channel = takenArgument.channel;
    int consumerAt = takenArgument.consumerAt;

    // Opening semophores
    sem_t *writeMutex;
    sem_t *readMutex;
    char name[20];
    sprintf(name, "writeMutex%d", channel);
    writeMutex = sem_open(name, O_CREAT | O_RDWR, 0600, 0);

    sprintf(name, "readMutex%d", channel);
    readMutex = sem_open(name, O_CREAT | O_RDWR, 0600, 0);

    char *message = malloc(charNumEachLine * sizeof(char));
    int successful = 1;
    while (successful)
    {
        sem_wait(readMutex);
        // Reading from buffer
        memcpy(message, *(*(buffer) + consumerAt),charNumEachLine);
        // Sending data to client
        send(socketNum, message, charNumEachLine, 0);
        // Getting response status (successful or not?)
        recv(socketNum, &successful, sizeof(int),0);
        usleep(40000); // For FPS, lesser than client
        sem_post(writeMutex);
        consumerAt = (consumerAt + 1) % bufferSize;
    }
    return (void *)0;
}
