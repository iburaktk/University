JavaFX library must be installed.
You should delete all semophores if program not works.
I implemented multiple channels that multiple clients can connect. (multiple clients per channel)
But, disconnect does not works;

You can run program as follows:
make
./sserver -p port -s streams -ch1 video1 -ch2 video2 -ch3 video3

javac --module-path PATH --add-modules javafx.controls,javafx.fxml sclient.java
java --module-path PATH --add-modules javafx.controls,javafx.fxml sclient -a address -p port -ch channel